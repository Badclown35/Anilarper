package app.anilarper.personal.ui.extras

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.anilarper.personal.Anime
import app.anilarper.personal.AniListApi
import app.anilarper.personal.AnimeFilters
import app.anilarper.personal.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private data class MalRow(val title: String, val score: Int, val status: String, val progress: Int, val total: Int?, val malId: Int? = null)
private data class MalImportResult(val imported: Int, val skipped: Int, val errors: Int)

/** Import a MyAnimeList anime-list CSV export and resolve titles to AniList IDs. */
@Composable
fun MalImportScreen(onImport: (Anime) -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf<List<MalRow>>(emptyList()) }
    var running by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0) }
    var diagnostics by remember { mutableStateOf<List<String>>(emptyList()) }
    var message by remember { mutableStateOf("Choose your MyAnimeList anime-list export (.xml).") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val parsed = runCatching {
                withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { parseMalExport(it.readText()) }
                        ?: error("Couldn't read that file.")
                }
            }
            parsed.onSuccess { rows = it; message = "${it.size} entries ready. Import resolves titles against AniList." }
                .onFailure { message = it.message ?: "MAL export couldn't be parsed." }
        }
    }
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Text("TRANSFER YOUR LIST", color = Violet, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Text("MAL import", color = White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
        Text("Import your MyAnimeList XML export; titles are matched to AniList IDs.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        Button(onClick = { picker.launch(arrayOf("application/xml", "text/xml", "text/*")) }, enabled = !running,
            colors = ButtonDefaults.buttonColors(containerColor = Violet, contentColor = Ink)) {
            Icon(Icons.Default.FileOpen, contentDescription = null); Text("Choose MAL XML")
        }
        Text(message, color = Muted, fontSize = 11.sp)
        if (running) LinearProgressIndicator(progress = { if (rows.isEmpty()) 0f else progress.toFloat()/rows.size }, modifier = Modifier.fillMaxWidth(), color = Violet)
        if (rows.isNotEmpty()) Button(onClick = {
            running = true; progress = 0
            scope.launch {
                var imported = 0; var skipped = 0; var errors = 0
                val issues = mutableListOf<String>()
                val resolvedByMalId = mutableMapOf<Int, Anime?>()
                val resolvedByTitle = mutableMapOf<String, Anime?>()
                rows.forEachIndexed { index, row ->
                    try {
                        val cacheKey = normalizeTitle(row.title)
                        val target = when {
                            row.malId != null && resolvedByMalId.containsKey(row.malId) -> resolvedByMalId[row.malId]
                            resolvedByTitle.containsKey(cacheKey) -> resolvedByTitle[cacheKey]
                            else -> resolveMalAnime(row).also {
                                resolvedByTitle[cacheKey] = it
                                row.malId?.let { id -> resolvedByMalId[id] = it }
                            }
                        }
                        if (target == null) {
                            skipped++
                            if (issues.size < 12) issues += "Skipped: ${row.title} (no exact AniList title match)"
                        } else {
                            val status = when (row.status.trim().lowercase()) {
                                "2", "completed" -> "COMPLETED"
                                "1", "watching" -> "WATCHING"
                                "3", "on-hold", "on hold" -> "PAUSED"
                                "4", "dropped" -> "DROPPED"
                                else -> "PLANNING"
                            }
                            onImport(target.copy(watchStatus = status,
                                progress = if (status == "COMPLETED" && target.episodes != null) target.episodes else row.progress,
                                score = row.score.takeIf { it > 0 } ?: target.score,
                                lastWatchedAt = System.currentTimeMillis()))
                            imported++
                        }
                    } catch (e: Exception) {
                        errors++
                        if (issues.size < 12) issues += "Error: ${row.title} — ${e.message ?: e.javaClass.simpleName}"
                    }
                    progress = index + 1
                    if (index < rows.lastIndex) delay(700)
                }
                diagnostics = issues.filter { it.startsWith("Error:") }.take(8) + issues.filter { it.startsWith("Skipped:") }.take(8)
                running = false
                message = "Imported $imported • skipped $skipped • errors $errors. ${if (errors > 0) "See error details below." else "Review duplicates in your library."}"
            }
        }, enabled = !running, colors = ButtonDefaults.buttonColors(containerColor = Violet, contentColor = Ink)) {
            Text(if (running) "Importing…" else "Import ${rows.size} entries")
        }
        if (diagnostics.isNotEmpty()) {
            Text("Import details (errors and skipped titles)", color = Violet, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            diagnostics.forEach { Text(it, color = Muted, fontSize = 10.sp) }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
            itemsIndexed(rows.take(100), key = { index, _ -> index }) { _, row ->
                Row(Modifier.fillMaxWidth().animeCard(RoundedCornerShape(10.dp)).padding(10.dp)) {
                    Text(row.title, color = White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text("${row.progress}/${row.total ?: "?"} • ${row.status}", color = Muted, fontSize = 10.sp)
                }
            }
            if (rows.size > 100) item { Text("Previewing first 100 of ${rows.size}. All entries import.", color = Muted, fontSize = 10.sp) }
        }
    }
}

private fun normalizeTitle(value: String) = value.lowercase().replace(Regex("[^a-z0-9]"), "")

private fun isTransientImportError(error: Exception): Boolean {
    val message = error.message.orEmpty().lowercase()
    return listOf("http 429", "http 500", "http 502", "http 503", "http 504",
        "timeout", "timed out", "connection reset", "unable to resolve host").any(message::contains)
}

private suspend fun <T> retryImportRequest(block: suspend () -> T): T {
    try {
        return block()
    } catch (e: Exception) {
        if (!isTransientImportError(e)) throw e
        delay(900)
        return block()
    }
}

private suspend fun retryAniListSearch(title: String): List<Anime> =
    retryImportRequest { AniListApi.search(title, 1, AnimeFilters()).items }

private suspend fun retryAniListMalId(malId: Int): Anime? =
    retryImportRequest { AniListApi.findByMalId(malId) }

private data class JikanCandidate(val malId: Int, val titles: List<String>)

private object JikanImportApi {
    suspend fun search(title: String): List<JikanCandidate> = withContext(Dispatchers.IO) {
        val encoded = URLEncoder.encode(title, "UTF-8")
        val connection = (URL("https://api.jikan.moe/v4/anime?q=$encoded&limit=10").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12000
            readTimeout = 18000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "Anilarper/1.0 (MAL import)")
        }
        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) error("Jikan returned HTTP $code")
            val data = JSONObject(response).optJSONArray("data") ?: return@withContext emptyList()
            buildList {
                for (i in 0 until data.length()) {
                    val item = data.optJSONObject(i) ?: continue
                    val id = item.optInt("mal_id")
                    if (id <= 0) continue
                    val titles = linkedSetOf<String>()
                    listOf("title", "title_english", "title_japanese").forEach { key ->
                        item.optString(key).takeIf { it.isNotBlank() && it != "null" }?.let(titles::add)
                    }
                    val alternatives = item.optJSONArray("titles")
                    for (j in 0 until (alternatives?.length() ?: 0)) {
                        alternatives?.optJSONObject(j)?.optString("title")
                            ?.takeIf { it.isNotBlank() && it != "null" }?.let(titles::add)
                    }
                    add(JikanCandidate(id, titles.toList()))
                }
            }
        } finally {
            connection.disconnect()
        }
    }
}

private suspend fun resolveMalAnime(row: MalRow): Anime? {
    row.malId?.let { malId ->
        retryAniListMalId(malId)?.let { return it }
    }

    val wanted = normalizeTitle(row.title)
    val direct = retryAniListSearch(row.title).firstOrNull { anime ->
        (listOf(anime.title, anime.romajiTitle, anime.nativeTitle) + anime.synonyms)
            .any { it.isNotBlank() && wanted == normalizeTitle(it) }
    }
    if (direct != null) return direct

    // Jikan is a MAL-derived fallback. Only accept an exact title/alias match,
    // then map by MAL ID to AniList's canonical ID before importing.
    delay(1100)
    val jikanMatches = JikanImportApi.search(row.title).filter { candidate ->
        candidate.titles.any { normalizeTitle(it) == wanted }
    }
    for (candidate in jikanMatches) {
        retryAniListMalId(candidate.malId)?.let { return it }

        // If AniList lacks the MAL cross-reference, search Jikan's verified
        // alternate titles and require a shared exact alias before accepting.
        for (alias in candidate.titles) {
            if (normalizeTitle(alias) == wanted) continue
            val aliases = retryAniListSearch(alias)
            val match = aliases.firstOrNull { anime ->
                val aniTitles = (listOf(anime.title, anime.romajiTitle, anime.nativeTitle) + anime.synonyms)
                    .filter(String::isNotBlank).map(::normalizeTitle).toSet()
                candidate.titles.any { normalizeTitle(it) in aniTitles }
            }
            if (match != null) return match
            delay(850)
        }
    }
    return null
}

private fun parseMalExport(raw: String): List<MalRow> {
    if (raw.trimStart().startsWith("<")) return parseMalXml(raw)
    return parseMalCsv(raw)
}

private fun parseMalXml(raw: String): List<MalRow> {
    val parser = Xml.newPullParser()
    parser.setInput(StringReader(raw))
    val result = mutableListOf<MalRow>()
    var fields: MutableMap<String, String>? = null
    val accepted = setOf("series_title", "anime_title", "title", "series_animedb_id", "anime_id", "my_score", "my_status",
        "my_watched_episodes", "anime_episodes", "series_episodes")
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.START_TAG -> {
                if (parser.name == "anime") fields = mutableMapOf()
                else if (fields != null && parser.name in accepted) {
                    fields!![parser.name] = parser.nextText().trim()
                }
            }
            XmlPullParser.END_TAG -> if (parser.name == "anime") {
                val item = fields.orEmpty()
                val title = item["series_title"] ?: item["anime_title"] ?: item["title"].orEmpty()
                if (title.isNotBlank()) result += MalRow(
                    title, item["my_score"]?.toIntOrNull() ?: 0, item["my_status"].orEmpty(),
                    item["my_watched_episodes"]?.toIntOrNull() ?: 0,
                    (item["series_episodes"] ?: item["anime_episodes"])?.toIntOrNull()?.takeIf { it > 0 },
                    (item["series_animedb_id"] ?: item["anime_id"])?.toIntOrNull()?.takeIf { it > 0 }
                )
                fields = null
            }
        }
        event = parser.next()
    }
    if (result.isEmpty()) error("No anime entries found. Choose the MyAnimeList anime-list XML export.")
    return result
}

private fun parseMalCsv(raw: String): List<MalRow> {
    val records = buildList {
        var row = mutableListOf<String>(); val field = StringBuilder(); var quoted = false; var i = 0
        while (i < raw.length) {
            val ch = raw[i]
            when {
                ch == '"' && quoted && i + 1 < raw.length && raw[i + 1] == '"' -> { field.append('"'); i++ }
                ch == '"' -> quoted = !quoted
                ch == ',' && !quoted -> { row += field.toString(); field.clear() }
                (ch == '\n' || ch == '\r') && !quoted -> {
                    row += field.toString(); field.clear()
                    if (row.any { it.isNotBlank() }) add(row)
                    row = mutableListOf()
                    if (ch == '\r' && i + 1 < raw.length && raw[i + 1] == '\n') i++
                }
                else -> field.append(ch)
            }
            i++
        }
        row += field.toString()
        if (row.any { it.isNotBlank() }) add(row)
    }
    if (records.size < 2) error("CSV is empty.")
    val headers = records.first().map { it.trim().removePrefix("\uFEFF").lowercase() }
    fun index(vararg names: String) = names.firstNotNullOfOrNull { headers.indexOf(it).takeIf { n -> n >= 0 } } ?: -1
    val titleI = index("anime_title", "title")
    val malIdI = index("anime_id", "series_animedb_id")
    val scoreI = index("my_score")
    val statusI = index("my_status")
    val progressI = index("my_watched_episodes")
    val totalI = index("anime_episodes")
    if (titleI < 0) error("Missing anime_title column. Use MyAnimeList's anime-list CSV export.")
    return records.drop(1).mapNotNull { row ->
        val title = row.getOrNull(titleI)?.trim().orEmpty()
        if (title.isBlank()) null else MalRow(title,
            row.getOrNull(scoreI)?.toIntOrNull() ?: 0,
            row.getOrNull(statusI)?.trim().orEmpty(),
            row.getOrNull(progressI)?.toIntOrNull() ?: 0,
            row.getOrNull(totalI)?.toIntOrNull()?.takeIf { it > 0 },
            row.getOrNull(malIdI)?.toIntOrNull()?.takeIf { it > 0 })
    }
}
